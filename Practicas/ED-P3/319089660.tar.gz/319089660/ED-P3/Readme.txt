Práctica 3: Recursión
Integrantes: 1
Nombre                              No. de cuenta   Correo
    Bonilla Reyes Dafne         -     319089660   -    daphnebonilla@ciencias.unam.mx

Comentarios(opcionales): Hola Alma :D, en esta práctica solo modifiqué las pruebas unitarias 
de suma_triangulo ya que el primer elemento no tenía [] como una lista.
