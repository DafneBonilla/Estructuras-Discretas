Práctica 6, primera parte: Fórmulas proposicionales
Integrantes: 2
Nombre                              No. de cuenta   Correo
Dafne Bonilla Reyes            -      319089660   -  daphnebonilla@ciencias.unam.mx
José Camilo García Ponce       -      319210536   -  jcamilo@ciencias.unam.mx

Comentarios: Hola Alma :D, solo queríamos comentarte que en evalua usamos fórmulas que vimos en álgebra superior.