Práctica 7, segunda parte: Tablas de verdad
Integrantes: 2
Nombre                              No. de cuenta   Correo
Dafne Bonilla Reyes            -      319089660   -  daphnebonilla@ciencias.unam.mx
José Camilo García Ponce       -      319210536   -  jcamilo@ciencias.unam.mx

Comentarios(opcionales):
estuve facil xd CoolCat